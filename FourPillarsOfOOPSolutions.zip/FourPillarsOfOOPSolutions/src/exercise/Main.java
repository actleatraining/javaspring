package exercise;

public class Main {
    public static void main(String[] args) {
        Vehicle[] vehicles = {
                new Car("Toyota", "Camry", 50.0, 4),
                new Motorcycle("Harley", "Sportster", 40.0, true)
        };

        for (Vehicle v : vehicles) {
            printRentalInfo(v, 3); // Polymorphism in action
        }
    }

    public static void printRentalInfo(Vehicle vehicle, int days) {
        System.out.println(vehicle.getInfo());
        System.out.println("Rental cost for " + days + " days: $" + vehicle.calculateRentalCost(days));
        System.out.println();
    }
}
