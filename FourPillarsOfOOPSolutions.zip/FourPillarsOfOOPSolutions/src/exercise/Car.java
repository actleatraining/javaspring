package exercise;

// Subclass 1 (Inheritance)
class Car extends Vehicle {
    private int numberOfDoors;

    public Car(String brand, String model, double price, int numberOfDoors) {
        super(brand, model, price);
        this.numberOfDoors = numberOfDoors;
    }

    @Override
    public double calculateRentalCost(int days) {
        return getRentalPricePerDay() * days;
    }

    @Override
    public String getVehicleType() {
        return "Car";
    }

    public int getNumberOfDoors() {
        return numberOfDoors;
    }
}

