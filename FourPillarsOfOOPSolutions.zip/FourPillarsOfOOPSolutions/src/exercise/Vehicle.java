package exercise;

// Abstract base class (Abstraction + Encapsulation)
abstract class Vehicle {
    private String brand;
    private String model;
    private double rentalPricePerDay;

    public Vehicle(String brand, String model, double rentalPricePerDay) {
        this.brand = brand;
        this.model = model;
        this.rentalPricePerDay = rentalPricePerDay;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentalPricePerDay() {
        return rentalPricePerDay;
    }

    public abstract double calculateRentalCost(int days);

    public abstract String getVehicleType();

    public String getInfo() {
        return getVehicleType() + " - " + brand + " " + model;
    }
}
