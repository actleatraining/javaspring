package com.hardcodeddependency;

public class LithiumIonBattery implements Battery {
    public void charge() {
        System.out.println("Lithium Ion Battery is charging...");
    }
}
