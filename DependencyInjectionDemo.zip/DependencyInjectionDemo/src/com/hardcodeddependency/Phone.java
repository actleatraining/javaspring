package com.hardcodeddependency;

public class Phone {
    //Battery battery = new LithiumIonBattery();
    Battery battery = new LithiumPolymerBattery();

    public void chargeBattery() {
        battery.charge();
    }
}
