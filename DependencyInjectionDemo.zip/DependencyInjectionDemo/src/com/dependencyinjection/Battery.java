package com.dependencyinjection;

public interface Battery {
    void charge();
}
