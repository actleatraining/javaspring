package com.dependencyinjection;

public class Phone {
    Battery battery;

    public Phone(Battery battery) {
        this.battery = battery;
    }

    public void chargeBattery() {
        battery.charge();
    }
}
