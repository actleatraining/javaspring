package com.dependencyinjection;

public class Main {

    public static void main(String[] args) {

        // Phones can now be created with different batteries
        // since the battery is injected from the outside and not hard-coded into the Phone class
        Phone phone = new Phone(new LithiumIonBattery());

        phone.chargeBattery();

        Phone phone2 = new Phone(new LithiumPolymerBattery());

        phone2.chargeBattery();
    }
}
