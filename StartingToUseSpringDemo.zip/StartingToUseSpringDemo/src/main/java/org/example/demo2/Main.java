package org.example.demo2;



/*
Steps to introduce Spring Framework

1. Add dependency to spring context in pom.xml (when using maven):

<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>6.1.2</version> <!-- eller den senaste -->
</dependency>

2. Annotate classes with @Component

Make CourseRepository a Spring managed bean

3. Configure Component Scan and the ApplicationContext

Add annotations to a new configuration class:

@Configuration
@ComponentScan


 */

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Creating an application context
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        // Get the repository as a bean from the application context
        CourseRepository repository = context.getBean(CourseRepository.class);

        Course course = repository.findById(2);
        System.out.println(course);
    }
}
