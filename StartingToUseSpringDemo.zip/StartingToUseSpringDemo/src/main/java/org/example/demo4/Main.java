package org.example.demo4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Creating an application context
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        // Get the service as a bean from the application context
        CourseService service = context.getBean(CourseService.class);

        Course course = service.getCourseById(1);
        System.out.println(course);
    }
}