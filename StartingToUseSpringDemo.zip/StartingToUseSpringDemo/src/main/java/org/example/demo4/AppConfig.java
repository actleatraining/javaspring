package org.example.demo4;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages = "org.example.demo4")
public class AppConfig {

    // Using @Bean annotated methods to create spring beans instead of component scan

    @Bean
    CourseRepository getCourseRepository() {
        return new CourseRepository();
    }

    @Bean
    CourseService getCourseService(CourseRepository repository) {
        return new CourseService(repository);
    }
}
