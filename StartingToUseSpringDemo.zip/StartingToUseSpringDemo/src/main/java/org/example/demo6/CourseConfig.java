package org.example.demo6;

import org.springframework.beans.factory.annotation.Value;

public class CourseConfig {

    @Value("${course.defaultTitle}")
    private String defaultTitle;

    public String getDefaultTitle() {
        return defaultTitle;
    }
}
