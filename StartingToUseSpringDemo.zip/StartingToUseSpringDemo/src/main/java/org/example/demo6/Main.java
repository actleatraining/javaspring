package org.example.demo6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContextDemo6.xml");

        CourseConfig config = (CourseConfig) context.getBean("courseConfig");

        System.out.println("Default course title: " + config.getDefaultTitle());
    }
}
