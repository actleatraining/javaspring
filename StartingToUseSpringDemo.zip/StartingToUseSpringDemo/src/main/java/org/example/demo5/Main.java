package org.example.demo5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        // Creating an application context - using a ClassPathXmlApplicationContext and applicationContext.xml
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        // Get the service as a bean from the application context by name
        CourseService service = (CourseService)context.getBean("courseService");

        Course course = service.getCourseById(1);
        System.out.println(course);
    }
}