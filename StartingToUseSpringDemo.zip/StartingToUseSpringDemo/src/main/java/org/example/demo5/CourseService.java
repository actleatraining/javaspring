package org.example.demo5;

import org.springframework.stereotype.Service;

@Service
public class CourseService {

    private CourseRepository repository;

    // Setter-injection
    public void setCourseRepository(CourseRepository courseRepository) {
        this.repository = courseRepository;
    }

    public Course getCourseById(int id) {
        return repository.findById(id);
    }
}
