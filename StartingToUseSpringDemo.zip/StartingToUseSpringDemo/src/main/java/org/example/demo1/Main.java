package org.example.demo1;

public class Main {
    public static void main(String[] args) {
        // Create the repository with new, without any help from spring
        CourseRepository repository = new CourseRepository();

        Course course = repository.findById(1);
        System.out.println(course);
    }
}