package org.example.demo1;

import java.util.HashMap;
import java.util.Map;

public class CourseRepository {
    private Map<Integer, Course> courses = new HashMap<>();

    public CourseRepository() {
        courses.put(1, new Course(1, "Java Basics", "Intro to Java"));
        courses.put(2, new Course(2, "Spring Intro", "Getting started with Spring"));
    }

    public Course findById(int id) {
        return courses.get(id);
    }
}
