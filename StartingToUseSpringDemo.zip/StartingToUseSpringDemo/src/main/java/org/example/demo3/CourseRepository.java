package org.example.demo3;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class CourseRepository {
    private Map<Integer, Course> courses = new HashMap<>();

    public CourseRepository() {
        courses.put(1, new Course(1, "Java Basics", "Intro to Java"));
        courses.put(2, new Course(2, "Spring Intro", "Getting started with Spring"));
    }

    public Course findById(int id) {
        return courses.get(id);
    }
}
