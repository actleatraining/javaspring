package org.example.demo3;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class CourseRepository {
    private Map<Integer, Course> courses = new HashMap<>();

    public CourseRepository() {
        System.out.println("repo");
        courses.put(1, new Course(1, "Java Basics", "Intro to Java"));
        courses.put(2, new Course(2, "Spring Intro", "Getting started with Spring"));
    }

    public Course findById(int id) {
        return courses.get(id);
    }
}
