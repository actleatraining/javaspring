package org.example.demo3;

import org.springframework.stereotype.Service;

@Service
public class CourseService {

    // @Autowired // Could use @Autowired or constructor injection
    private final CourseRepository repository;

    // Constructor injection, or use @Autowired annotation directly on the instance variable
    public CourseService(CourseRepository repository) {
        this.repository = repository;
    }

    public Course getCourseById(int id) {
        return repository.findById(id);
    }
}
