package org.example.demo3;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CourseService {

    @Autowired // Could use @Autowired or constructor injection
    private  CourseRepository repository;

    public Course getCourseById(int id) {
        return repository.findById(id);
    }
}
