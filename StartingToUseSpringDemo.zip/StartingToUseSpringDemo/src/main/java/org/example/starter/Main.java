package org.example.starter;


public class Main {
    public static void main(String[] args) {
        // Create the repository with new, without any help from spring
        BookRepository repository = new BookRepository();

        Book book = repository.findById(2);
        System.out.println(book);
    }
}
