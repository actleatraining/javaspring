package org.example.starter;

import java.util.HashMap;
import java.util.Map;

public class BookRepository {
    private Map<Integer, Book> books = new HashMap<>();

    public BookRepository() {
        books.put(1, new Book(1, "Lord of the Rings", "J R R Tolkien", 299));
        books.put(2, new Book(2, "Pippi Longstocking", "Astrid Lindgren", 349));
    }

    public Book findById(int id) {
        return books.get(id);
    }
}
