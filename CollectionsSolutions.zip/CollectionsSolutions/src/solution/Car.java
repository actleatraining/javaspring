package solution;

public class Car extends Vehicle {
    public Car(String licensePlate) {
        super(licensePlate);
    }

    public void drive() {
        System.out.println("Car is driving.");
    }
}
