package demo1;

public record Dog(String name, int age) {
}
