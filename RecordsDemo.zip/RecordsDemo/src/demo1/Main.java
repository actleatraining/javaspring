package demo1;

public class Main {
    public static void main(String[] args) {
        // Creating a record by using the automatic constructor, it will automatically create  private final instance variables
        Dog dog = new Dog("Chicco", 2);

        // No getters with get... instead the variable name is used as accessor method name
        String name = dog.name();
        int age = dog.age();

        // Immutability - no way to set or change values

        System.out.println(dog); // Automatic toString method

        Dog dog2 = new Dog("Chicco", 2);
        Dog dog3 = new Dog("Pluto", 73);

        // Automatic equals
        System.out.println(dog.equals(dog2));
        System.out.println(dog2.equals(dog3));

        // Automatic hashCode
        System.out.println(dog.hashCode());
        System.out.println(dog2.hashCode());
        System.out.println(dog3.hashCode());
    }
}