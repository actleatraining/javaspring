package demo2;

public record Dog(String name, int age) {
    void wagTail(){
        System.out.println(name + " is wagging the tail!");
    }
}
