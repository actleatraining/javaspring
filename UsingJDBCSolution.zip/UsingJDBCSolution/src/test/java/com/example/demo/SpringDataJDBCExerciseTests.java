package com.example.demo;

import com.example.demo.exercise.BookRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class SpringDataJDBCExerciseTests {

	@Autowired
	BookRepository repository;

	@Test
	void contextLoads() {
	}


	// todo uncomment these tests (maybe one at a time) and make sure they pass!


	@Test
	void count() {
		int count = repository.count();
		Assertions.assertEquals(2, count);
	}

	@Test
	void findAll() {
		List<Book> books = repository.findAll();
		Assertions.assertEquals(3, books.size());
	}

	@Test
	void findById() {
		Book book = repository.findById(1L);
		Assertions.assertEquals("Homer", book.getAuthor());
	}

	@Test
	void updateBook() {
		Book book = repository.findById(1L);

		int price = book.getPrice();

		book.setPrice(price*2);
		repository.updatePrice(book);

		Book updatedBook = repository.findById(1L);
		Assertions.assertEquals(price*2, updatedBook.getPrice());
	}

	@Test
	void findByAuthor() {
		List<Book> books = repository.findByAuthor("Astrid Lindgren");

		Assertions.assertEquals(1, books.size());
	}
}
