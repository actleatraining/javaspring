package com.example.demo.exercise;

import com.example.demo.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BookRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    // todo Create all Repository methods that are needed!

    public int count() {
        return jdbcTemplate
                .queryForObject("select count(*) from dog", Integer.class);
    }

    public List<Book> findAll() {
        List<Book> books = jdbcTemplate.query(
                "select * from book",
                new BookRowMapper());
        return books;
    }

    public Book findById(Long id) {
        Book book = jdbcTemplate.queryForObject(
                "select * from book where id = ?",
                new Object[]{id},
                new BookRowMapper());
        return book;
    }

    public int updatePrice(Book book) {
        return jdbcTemplate.update(
                "update book set price = ? where id = ?",
                book.getPrice(), book.getId());
    }

    public List<Book> findByAuthor(String name) {
        List<Book> books = jdbcTemplate.query(
                "select * from book where author like ?",
                new Object[]{"%" + name + "%"},
                new BookRowMapper());
        return books;
    }
}
