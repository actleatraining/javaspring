INSERT INTO DOG (NAME, AGE) VALUES ('Pluto', 90);
INSERT INTO DOG (NAME, AGE) VALUES ('Fido', 3);

INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('The Iliad', 'Homer', 300);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('The Hitchhikers Guide to the Galaxy', 'Douglas Adams', 500);
INSERT INTO BOOK (TITLE, AUTHOR, PRICE) VALUES ('Pippi Longstocking', 'Astrid Lindgren', 250);