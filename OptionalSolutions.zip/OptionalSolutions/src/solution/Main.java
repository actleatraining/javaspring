package solution;

import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Optional<Car> car = Optional.of(new Car("ABC123"));
        car.ifPresent(c -> System.out.println("License: " + c.getLicensePlate()));

        Optional<Car> emptyCar = Optional.empty();

        // Using an if statement and isPresent()
        if (emptyCar.isPresent()) {
            System.out.println("License: " + emptyCar.get().getLicensePlate());
        } else {
            System.out.println("No car available");
        }

        // Using ifPresentOrElse()
        emptyCar.ifPresentOrElse(
                c -> System.out.println("License: " + c.getLicensePlate()),
                () -> System.out.println("No car available")
        );
    }
}
