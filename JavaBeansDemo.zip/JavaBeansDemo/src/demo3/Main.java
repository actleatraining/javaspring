package demo3;

public class Main {
    public static void main(String[] args) {

        Dog pluto1 = new Dog("Pluto", 73);
        Dog pluto2 = new Dog("Pluto", 73);

        System.out.println(pluto1.hashCode());
        System.out.println(pluto2.hashCode());

        Cat misse1 = new Cat("Misse", 4);
        Cat misse2 = new Cat("Misse", 4);

        System.out.println(misse1.hashCode());
        System.out.println(misse2.hashCode());
    }
}
