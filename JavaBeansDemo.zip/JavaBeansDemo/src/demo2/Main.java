package demo2;

public class Main {
    public static void main(String[] args) {

        Dog pluto1 = new Dog("Pluto", 73);
        Dog pluto2 = new Dog("Pluto", 73);

        // The two dogs are not equal because the inherited equals method only compare object references and the references are different even if the values in the dogs are equal
        if (pluto1.equals(pluto2)) {
            System.out.println("pluto1 and pluto2 are equal");
        }
        else {
            System.out.println("pluto1 and pluto2 are not equal");
        }

        Cat misse1 = new Cat("Misse", 4);
        Cat misse2 = new Cat("Misse", 4);

        // The two cats are equal because the overridden method in Cat compares the values in the instance variables and those are equal
        if (misse1.equals(misse2)) {
            System.out.println("misse1 and misse2 are equal");
        }
        else {
            System.out.println("misse1 and misse2 are not equal");
        }
    }
}
