package demo1;

public class Main {
    public static void main(String[] args) {

        Dog dog = new Dog("Pluto", 73);

        // Printing a demo3.Dog object will call the toString method and print the result
        System.out.println(dog);
        // Without overriding toString the inherited toString method from Object will only print class name, then @, then unsigned hexadecimal representation of the hash code

        // demo3.Cat has overridden the toString method to make it more useful
        Cat cat = new Cat("Misse", 4);

        System.out.println(cat);
    }
}
