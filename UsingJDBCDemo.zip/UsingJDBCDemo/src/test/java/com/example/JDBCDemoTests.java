package com.example;

import com.example.jdbc.JDBCBookRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class JDBCDemoTests {

	@Autowired
	private JDBCBookRepository bookRepository;

	@Test
	public void testBooksCount() {
		int count = bookRepository.getBooksCount();
		Assertions.assertEquals(3, count);
	}


	@Test
	public void testGetBooks() {
		List<Book> books = bookRepository.getBooks();
		Assertions.assertEquals(3, books.size());
	}



	@Test
	public void testGetBookWithId() {
		Book book = bookRepository.getBook(2);
		Assertions.assertEquals("Douglas Adams", book.getAuthor());
	}



	@Test
	public void testGetBooksByAuthor() {
		List<Book> books = bookRepository.getBooksByAuthor("Homer");
		Assertions.assertEquals("The Iliad", books.get(0).getTitle());

		int count = bookRepository.getBooksCount();
		List<Book> books2 = bookRepository.getBooksByAuthor("Homer' or author not like 'Homer");
		Assertions.assertEquals(count, books2.size());
	}


	@Test
	public void testGetBooksByAuthorSafe() {
		List<Book> books = bookRepository.getBooksByAuthorSafe("Homer");
		Assertions.assertEquals("The Iliad", books.get(0).getTitle());

		List<Book> books2 = bookRepository.getBooksByAuthorSafe("Homer' or author not like 'Homer");
		Assertions.assertEquals(0, books2.size());
	}



	@Test
	public void testGetBooksByCustomer() {
		List<Book> books = bookRepository.getBooksByCustomer("Donald");
		Assertions.assertEquals("Douglas Adams", books.get(0).getAuthor());
	}



	@Test
	public void testAddBook() {
		int count = bookRepository.getBooksCount();
		bookRepository.addBook(new Book(null, "New Book Title", "Test Class", 1));
		List<Book> books = bookRepository.getBooks();

		Assertions.assertEquals((count+1), books.size());

		Book lastBook = books.get(books.size()-1);

		Assertions.assertEquals("Test Class", lastBook.getAuthor());
	}



	@Test
	public void testGetBooksMeta() {
		int count = bookRepository.getBooksCount();
		List<Book> books = bookRepository.getBooksMeta();
		Assertions.assertEquals(count, books.size());
	}

	// Testing 2 different testCustomerCount methods to see the difference between using try with resources and not using it
	@Test
	public void testCustomerCount() {
		int count = bookRepository.getCustomerCount();
		Assertions.assertEquals(3, count);
	}

	@Test
	public void testCustomerCount2() {
		int count = bookRepository.getCustomerCount2();
		Assertions.assertEquals(3, count);
	}

	// Testing some methods to try out sql injection and using string concatenation and prepared statement
	@Test
	public void testCustomer() {
		int i = bookRepository.getCustomer("1");
		Assertions.assertEquals(1, i);
	}

	@Test
	public void testCustomerInjection() {
		int i = bookRepository.getCustomer("1 or 1=1");
		Assertions.assertEquals(3, i);
	}

	@Test
	public void testCustomerPrepared() {
		int i = bookRepository.getCustomerPrepared("1");
		Assertions.assertEquals(1, i);
	}

	@Test
	public void testCustomerPreparedInjection() {
		int i = bookRepository.getCustomerPrepared("1 or 1=1");
		Assertions.assertEquals(0, i);
	}
}
