package com.example.springjdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DogRepository {
    @Autowired
    JdbcTemplate jdbcTemplate;

    public int count() {
        return jdbcTemplate
                .queryForObject("select count(*) from dog", Integer.class);
    }

    public List<Dog> findAll() {
        List<Dog> dogs = jdbcTemplate.query(
                "select * from dog",
                new DogRowMapper());
        return dogs;
    }

    public Dog findById(Long id) {
        Dog dog = jdbcTemplate.queryForObject(
                "select * from dog where id = ?",
                new Object[]{id},
                new DogRowMapper());
        return dog;
    }

    public int updateAge(Dog dog) {
        return jdbcTemplate.update(
                "update dog set age = ? where id = ?",
                dog.getAge(), dog.getId());
    }

    public List<Dog> findByName(String name) {
        List<Dog> dogs = jdbcTemplate.query(
                "select * from dog where name like ?",
                new Object[]{"%" + name + "%"},
                new DogRowMapper());
        return dogs;
    }

    public int save(Dog dog) {
        return jdbcTemplate.update(
                "insert into dog (name, age) values(?,?)",
                dog.getName(), dog.getAge());
    }

    public int deleteById(Long id) {
        return jdbcTemplate.update(
                "delete dog where id = ?",
                id);
    }
}
