package com.example.springjdbc;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DogRowMapper implements RowMapper<Dog> {
    @Override
    public Dog mapRow(ResultSet rs, int rowNum) throws SQLException {

        Dog dog = new Dog();
        dog.setId(rs.getLong("ID"));
        dog.setName(rs.getString("NAME"));
        dog.setAge(rs.getInt("AGE"));

        return dog;
    }
}


