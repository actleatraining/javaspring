package com.example.jdbc;

import com.example.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class JDBCBookRepository {

    @Autowired
    private DataSource dataSource;

    public int getBooksCount() {
        int bookCount = 0;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS bookCount FROM book")) {

            if (rs.next()){
                bookCount = rs.getInt("bookCount");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookCount;
    }


    public List<Book> getBooks() {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, title, author, price FROM book")) {

            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }


    public Book getBook(int id) {
        Book book = null;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM book WHERE id = " + id)) {

            if (rs.next()){
                book = rsBook(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return book;
    }


    public List<Book> getBooksByAuthor(String author) {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, title, author, price FROM book WHERE author = '" + author + "'")) {

            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    public List<Book> getBooksByAuthorSafe(String author) {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT id, title, author, price FROM book WHERE author = ?")) {
            ps.setString(1, author);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    public List<Book> getBooksByCustomer(String customer) {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();

             PreparedStatement ps = conn.prepareStatement("SELECT B.ID, B.TITLE, B.AUTHOR, B.PRICE FROM BOOK AS B " +
                     "JOIN PURCHASE AS P " +
                     "ON B.ID = P.BOOK_ID " +
                     "JOIN CUSTOMER AS C " +
                     "ON P.CUSTOMER_ID = C.ID " +
                     "WHERE C.FIRST_NAME = ?")) {
            ps.setString(1, customer);
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                books.add(rsBook(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }


    public void addBook(Book book) {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO BOOK(TITLE, AUTHOR, PRICE) VALUES (?,?,?) ")) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setInt(3, book.getPrice());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method similar to addBook that also gets the generated id of the book
    public int addBookAndGetId(Book book) {
        int generatedId = -1;
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO BOOK(TITLE, AUTHOR, PRICE) VALUES (?,?,?) ", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setInt(3, book.getPrice());
            ps.executeUpdate();

            //Get the ID of the newly created order row
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                generatedId = rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return generatedId;
    }


    public List<Book> getBooksMeta() {
        List<Book> books = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM book")) {

            // part 1
            ResultSetMetaData meta = rs.getMetaData();
            int columns = meta.getColumnCount();
            System.out.println("Columns " + columns);
            for (int i = 1; i <= columns; i++ ) {
                String name = meta.getColumnName(i);
                String type = meta.getColumnTypeName(i);
                System.out.println("Column " +name +" (" + type +")");
            }

            // part 2
            System.out.println("DATA:");
            while (rs.next()){
                books.add(rsBook(rs));
                for (int i = 1; i <= columns; i++ ) {
                    String name = meta.getColumnName(i);
                    String type = meta.getColumnTypeName(i);

                    if (type.equals("BIGINT")) {
                        System.out.println(name + ": " + rs.getInt(name));
                    }
                    else if (type.equals("VARCHAR")) {
                        System.out.println(name + ": " + rs.getString(name));
                    }
                }
                System.out.println();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }


    // Testing some methods to try out sql injection and using string concatenation and prepared statement
    public int getCustomerCount() {
        int count = 0;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS C FROM CUSTOMER")) {
            if (rs.next()){
                count = rs.getInt("C");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }

    public int getCustomerCount2() {
        int count = 0;
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS C FROM CUSTOMER");
            if (rs.next()){
                count = rs.getInt("C");
                rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return count;
    }

    public int getCustomer(String id) {
        int i = 0;
        String firstName = null;
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT FIRST_NAME FROM CUSTOMER WHERE ID=" + id)) {
            while (rs.next()){
                i++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }


    public int getCustomerPrepared(String id) {
        int i = 0;
        String firstName = null;
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM CUSTOMER WHERE ID=?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()){
                i++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    // Helper method to create a Book object instantiated with data from the ResultSet
    private Book rsBook(ResultSet rs) throws SQLException {
        return new Book(rs.getLong("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getInt("price"));
    }
}
