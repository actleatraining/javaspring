package org.example.solution2;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    // @Autowired // Could use @Autowired or constructor injection
    private final BookRepository repository;

    // Constructor injection, or use @Autowired annotation directly on the instance variable
    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public Book getBookById(int id) {
        return repository.findById(id);
    }
}
