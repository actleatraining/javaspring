package org.example.solution1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        BookRepository repository = context.getBean(BookRepository.class);

        Book book = repository.findById(2);
        System.out.println(book);
    }
}
