package exercise3;

public class Main {
    public static void main(String[] args) {

        Book lordOfTheRings1 = new Book("Lord of the Rings", "J R R Tolkien", 299);
        Book lordOfTheRings2 = new Book("Lord of the Rings", "J R R Tolkien", 299);

        System.out.println(lordOfTheRings1.hashCode());
        System.out.println(lordOfTheRings2.hashCode());
    }
}
