package exercise1;

public class Main {
    public static void main(String[] args) {
        Book lordOfTheRings = new Book("The Lord of the Rings", "J R R Tolkien", 299);

        System.out.println(lordOfTheRings.author());
    }
}
