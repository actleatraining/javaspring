package exercise1;

public record Book(String author, String title, int price) {
}
