package demo1;

public class Main {
    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount("Anna", 1000);

        System.out.println(bankAccount.getBalance());
    }
}
