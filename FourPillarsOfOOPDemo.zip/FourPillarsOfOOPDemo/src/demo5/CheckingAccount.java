package demo5;

class CheckingAccount implements BankAccount {
    private String owner;
    private double balance;
    private double fee = 5.0;

    public CheckingAccount(String owner, double initialBalance) {
        this.owner = owner;
        if (initialBalance >= 0) {
            this.balance = initialBalance;
        } else {
            this.balance = 0;
        }
    }

    @Override
    public void deposit(double amount) {
        balance += amount;
        System.out.println(owner + " deposited " + amount);
    }

    @Override
    public void endOfMonth() {
        balance -= fee;
        System.out.println("Monthly fee charged for " + owner + ": " + fee);
    }

    public void printBalance() {
        System.out.println(owner + "'s balance: " + balance);
    }
}
