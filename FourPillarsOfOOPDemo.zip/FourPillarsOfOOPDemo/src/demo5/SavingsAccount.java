package demo5;

public class SavingsAccount implements BankAccount {
    private String owner;
    private double balance;
    private double interestRate;

    public SavingsAccount(String owner, double initialBalance, double interestRate) {
        this.owner = owner;
        if (initialBalance >= 0) {
            this.balance = initialBalance;
        } else {
            this.balance = 0;
        }
        this.interestRate = interestRate;
    }

    public void deposit(double amount) {
        balance += amount;
        System.out.println(owner + " deposited " + amount);
    }

    @Override
    public void endOfMonth() {
        double interest = balance * interestRate;
        balance += interest;
        System.out.println("Savings interest added for " + owner + ": " + interest);
    }

    public void printBalance() {
        System.out.println(owner + "'s balance: " + balance);
    }
}
