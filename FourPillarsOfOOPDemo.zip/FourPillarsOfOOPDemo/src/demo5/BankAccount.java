package demo5;

interface BankAccount {
    void deposit(double amount);
    void endOfMonth();
    void printBalance();
}