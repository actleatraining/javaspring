package demo2;

public class Main {
    public static void main(String[] args) {
        SavingsAccount bankAccount = new SavingsAccount("Anna", 1000, 0.05);

        bankAccount.applyInterest();
        System.out.println(bankAccount.getBalance());
    }
}
