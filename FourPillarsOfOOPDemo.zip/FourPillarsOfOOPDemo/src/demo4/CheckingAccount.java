package demo4;

class CheckingAccount extends BankAccount {
    private double fee = 5.0;

    public CheckingAccount(String owner, double balance) {
        super(owner, balance);
    }

    @Override
    public void endOfMonth() {
        balance -= fee;
        System.out.println("Monthly fee charged for " + owner + ": " + fee);
    }
}
